/*:
## App Exercise - Workout Extensions

 >These exercises reinforce Swift concepts in the context of a fitness tracking app.

 Add an extension to the `Workout` struct below and make it adopt the `CustomStringConvertible` protocol.
 */
struct Workout: CustomStringConvertible {
    var description: String
    
    var distance: Double
    var time: Double
    var averageHR: Int
}

//:  Now create another extension for `Workout` and add a property `speed` of type `Double`. It should be a computed property that returns the average meters per second traveled during the workout.
extension Workout {
    var speed: Double {
        return distance / time
    }
    
    
}

//:  Now add a method `harderWorkout` that takes no parameters and returns another `Workout` instance. This method should double the `distance` and `time` properties, and add 40 to `averageHR`. Create an instance of `Workout` and print it to the console. Then call `harderWorkout` and print the new `Workout` instance to the console.
extension Workout {
    func harderWorkout() -> Workout {
        return Workout(description: "Harder Workout", distance: distance * 2, time: time * 2, averageHR: averageHR + 40)
    }
}
let myWorkout = Workout(description: "Workout", distance: 5.0, time: 30.0, averageHR: 120)
let harderWorkout = myWorkout.harderWorkout( )
print(harderWorkout.description, harderWorkout.distance, harderWorkout.time, harderWorkout.averageHR, harderWorkout.speed)
